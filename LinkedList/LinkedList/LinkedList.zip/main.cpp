#include <iostream>
#include <string.h>
#include "Node.h"
#include "LinkedList.h"

using namespace std;

int main() {

	Node<int> node;
	Node<string> strNode;
	LinkedList<int> linkedlist;

	node.setData(1);
	strNode.setData("�ѱ�");

	linkedlist.push(1);

	cout << node.getData() << "," << strNode.getData() << endl;



	return 0;

}