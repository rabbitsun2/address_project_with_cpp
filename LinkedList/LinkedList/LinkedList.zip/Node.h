#pragma once
#ifndef _NODE_H

#include <iostream>

using namespace std;

template <typename T>
class Node {

	private:
		T data;
		Node<T>* link;

	public:
		T getData();
		Node<T>* getLink();

		void setData(T data);
		void setLink(Node<T>* link);

	protected:


};


template <typename T>
T Node<T>::getData() {
	return data;
}

template <typename T>
Node<T>* Node<T>::getLink() {
	return link;
}

template <typename T>
void Node<T>::setData(T data) {
	this->data = data;
}

template <typename T>
void Node<T>::setLink(Node<T>* link) {
	this->link = link;
}

#endif // !_NODE_H

