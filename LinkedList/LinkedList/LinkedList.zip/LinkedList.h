#pragma once
#ifndef _LINKED_LIST_H_

#include <iostream>
#include "Node.h"

using namespace std;

template <typename T>
class LinkedList {

private:
	Node<T>* first;
	Node<T>* current;

public:
	LinkedList();
	~LinkedList();

	void push(T data);
	T pop();

protected:

};

template <typename T>
LinkedList<T>::LinkedList() {

	this->first = NULL;
	this->current = NULL;

}

template <typename T>
LinkedList<T>::~LinkedList() {

}

template <typename T>
void LinkedList<T>::push(T data) {

	Node<T>* pNode = first;

	pNode = new Node<T>();
	pNode->setData(data);
	pNode->setLink(NULL);

	// ��尡 ���� ��
	if (this->first == NULL) {

		this->first = pNode;
		this->current = pNode;

	}
	// ��� �߰�
	else {
		current->setLink(pNode);
		pNode = pNode->getLink();
		current = pNode;
	}

}

template <typename T>
T LinkedList<T>::pop() {

	T data = NULL;
	
	if (current != NULL){
		data = current->getData();

		return data;
	}
	

}


#endif // !_LINKED_LIST_H_